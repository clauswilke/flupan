"""``flupan`` package for interpreting influenza virus passage annotatons.
Written by Claire D. McWhite
Test modules
----------------
* test_flupan.py
"""
import sys

from flupan import *
#from .passage_interpreter import *

